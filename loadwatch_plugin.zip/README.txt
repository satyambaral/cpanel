INSTALLATION:

1. Extract files to server
2. Copy PHP files to:
/usr/local/cpanel/base/frontend/jupiter/loadwatch/

3. Copy script:
/usr/local/cpanel/scripts/loadwatch_check.sh
chmod +x it

4. Install dependencies:
yum install jq mailx -y

5. Create config:
/etc/loadwatch_config.json

6. Add cron:
* * * * * /usr/local/cpanel/scripts/loadwatch_check.sh

7. Register plugin:
Create /var/cpanel/apps/loadwatch.conf and run:
/usr/local/cpanel/bin/register_appconfig loadwatch.conf
