#!/bin/bash
CONFIG="/etc/loadwatch_config.json"
STATE="/tmp/loadwatch_state"

THRESHOLD=$(jq .threshold $CONFIG)
DURATION=$(jq .duration $CONFIG)
EMAIL=$(jq -r .email $CONFIG)

LOAD=$(uptime | awk -F'load average:' '{print $2}' | cut -d',' -f1 | xargs)
LOAD_INT=${LOAD%.*}
TIME=$(date +%s)

send_email(){ echo "$2" | mail -s "$1" "$EMAIL"; }

if [ "$LOAD_INT" -gt "$THRESHOLD" ]; then
 if [ ! -f "$STATE" ]; then echo $TIME > $STATE; send_email "High Load" "Load $LOAD"; exit 0; fi
 START=$(cat $STATE)
 ELAPSED=$(( (TIME - START) / 60 ))
 if [ "$ELAPSED" -ge "$DURATION" ]; then send_email "Reboot" "Load $LOAD"; /sbin/reboot; fi
else
 rm -f $STATE
fi
